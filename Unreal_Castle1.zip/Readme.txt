Unreal_Castle1.wad by A. "Danz" Brutus

A bunch of medieval textures converted from Unreal for Quake 1 usage, with a few extra helpful custom textures like the rune keys and the arrow guide.
These were never used in the final version of Unreal, possibly cut due to them looking very early wip compared to the ones Unreal used in the end.

Have fun using them. :)